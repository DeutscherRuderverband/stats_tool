from datetime import date

# Set the variables for the script

DATE_FROM = date(2024, 8, 1)
DATE_TO = date(2024, 8, 31)

DATABASE_URL = 'postgresql://username:password@host:port/database_name'